export default {
  cameraOutline: ''
}
