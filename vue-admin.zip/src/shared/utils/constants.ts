export const defaultLocale = 'ru'

export const localeOptions = <const>[
  { id: 'en', name: 'English' },
  { id: 'ru', name: 'Russian' },
  { id: 'uz', name: 'Uzbek' }
]
