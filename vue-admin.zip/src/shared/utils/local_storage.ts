export const setItem: any = (name: string, data: any) => localStorage.setItem(name, data)
export const getItem: any = (name: string) => localStorage.getItem(name)
export const removeItem: any = (name: string) => localStorage.removeItem(name)
